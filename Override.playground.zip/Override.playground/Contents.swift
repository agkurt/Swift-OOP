import UIKit

class Animal {
    func volume() {
        print("make noise")
    }
}

 
